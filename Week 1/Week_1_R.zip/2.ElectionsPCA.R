# PCA USA county-wise election results:

df<-read.csv("USelections2016.csv")

df<-df[,-1]

pca.out<-prcomp(df)

plot(pca.out, type="l")
summary(pca.out)
biplot(pca.out, col=c("grey","red"))


pca.out<-prcomp(df, scale.=TRUE)

plot(pca.out, type="l")
summary(pca.out)
biplot(pca.out, col=c("grey","red"))

# Select variables: Remove pop2010 (change + 2014) and Female (no variance)

pca.data<-df[,c(-1, -4,-9)]

pca.out<-prcomp(pca.data, scale.=TRUE)
plot(pca.out, type="l")

biplot(pca.out, col=c("grey","red"))

pca.out3<-pca.out$rotation[,1:3]
pca.rot<-varimax(pca.out3)
pca.rot

# PCA county data:

counties<-df[,3:34]
pca.out<-prcomp(counties, scale.=TRUE)
plot(pca.out, type="l")
biplot(pca.out, col=c("grey","red"))

# Add explained variances to axes. First, calculate variance per dimension:

vars<-pca.out$sdev^2
totvar<-sum(vars)
explvar<-vars/totvar

# Make labels for the axes:

axes.labs <- paste('PC', 1:2, sep='')

# Append the proportion of explained variance to the axis labels
axes.labs <- paste(axes.labs, 
                   sprintf('(%0.1f%% explained var.)', 
                           100 * explvar[1:2]))

colnames(pca.out$x)[1:2]<- axes.labs

biplot(pca.out, col=c("grey","red"))#, xlabs=parties, ylabs=stelling)

pca3<-pca.out$rotation[,1:3]
pcarot<-varimax(pca3)

