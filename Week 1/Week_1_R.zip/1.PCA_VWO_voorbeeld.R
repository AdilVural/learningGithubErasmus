# Open de data

df<-read.csv("vwodata.csv")
df<-df[,-1]
boxplot(df)

pca.out<-prcomp(df)
plot(pca.out,type="l")
summary(pca.out)

vars<-pca.out$sdev^2
totvar<-sum(vars)
explvar<-vars/totvar

biplot(pca.out)
biplot(pca.out, cex=c(0.5,1), col=c("grey","red"))

# Plaats verklaarde variantie bij assen. Beetje gedoe. Moet in pca.out:

axes.labs <- paste('PC', 1:2, sep='')
# Append the proportion of explained variance to the axis labels
axes.labs <- paste(axes.labs, 
                   sprintf('(%0.1f%% explained var.)', 
                           100 * explvar[1:2]))
colnames(pca.out$x)[1:2]<- axes.labs

### Einde verklaarde variantie bij assen. Informatie zit in pca.out ######

biplot(pca.out,cex=c(0.5,1), col=c("grey","red"))

k<-3
ladingen<-pca.out$rotation[,1:k]
vari.rot<-varimax(ladingen)
vari.rot
vari.rot$loadings

pca.out.scores<-pca.out$x[,1:k]                 # De oorspronkelijke scores
scores.rot<-pca.out.scores %*% vari.rot$rotmat  # De geroteerde scores

biplot(scores.rot, vari.rot$loadings, col=c("grey","red"))


